sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("cd_laasstaging_fs.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);